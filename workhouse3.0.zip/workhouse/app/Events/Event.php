<?php

namespace Workhouse\Events;

abstract class Event
{
    //
}
